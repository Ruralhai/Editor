export function generatePrompt(project: {
    product_name: string;
    brand_name: string;
    industry: string;
    category: string;
    description: string;
    target_audience: string;
    packaging_type: string;
    packaging_style: string;
    material: string;
    finish: string;
    printing_method: string;
    sustainability: string[];
    primary_color: string;
    secondary_color: string;
    design_style: string;
    language: string;
    market: string;
    required_text: string;
    ai_instructions: string;
}) {
    return `
Create a highly realistic premium packaging design.
 
Brand Name:
${project.brand_name}
 
Product Name:
${project.product_name}
 
Industry:
${project.industry}
 
Category:
${project.category}
 
Product Description:
${project.description}
 
Target Audience:
${project.target_audience}
 
Packaging Type:
${project.packaging_type}
 
Packaging Style:
${project.packaging_style}
 
Material:
${project.material}
 
Finish:
${project.finish}
 
Printing Method:
${project.printing_method}
 
Sustainability Features:
${project.sustainability.join(", ")}
 
Primary Color:
${project.primary_color}
 
Secondary Color:
${project.secondary_color}
 
Design Style:
${project.design_style}
 
Language:
${project.language}
 
Target Market:
${project.market}
 
Required Text:
${project.required_text}
 
Additional Instructions:
${project.ai_instructions}
 
Design Requirements:
 
• Premium commercial packaging
• Modern typography
• Balanced composition
• High-end branding
• Photorealistic product mockup
• Professional lighting
• Clean background
• Print-ready appearance
• Ultra-detailed
• 4K quality
`;
}
