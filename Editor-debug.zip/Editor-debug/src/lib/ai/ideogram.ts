import axios from "axios";

const apiKey = process.env.IDEOGRAM_API_KEY;

if (!apiKey) {
    throw new Error("IDEOGRAM_API_KEY is not set.");
}

export const ideogram = axios.create({
    baseURL: "https://api.ideogram.ai",
    headers: {
        "Api-Key": apiKey,
    },
});
