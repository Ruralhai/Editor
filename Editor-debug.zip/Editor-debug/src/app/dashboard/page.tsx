"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabase";

export default function DashboardPage() {
    const router = useRouter();

    const [projects, setProjects] = useState<any[]>([])

    useEffect(() => {
        checkUser();
    }, []);

    async function checkUser() {
        const {
            data: { session },
        } = await supabase.auth.getSession();

        if (!session) {
            router.push("/login");
        }

        else {
            const { data, error } = await supabase
                .from("projects")
                .select("*")
                .eq("user_id", session.user.id)
                .order("updated_at", { ascending: false });

            if (!error && data) {
                setProjects(data);
            }
        } // close else

    } // close checkUser()

    async function handleLogout() {
        await supabase.auth.signOut();
        router.push("/login");
    }
    return (
        <main className="min-h-screen bg-slate-950 text-white">
            <header className="flex items-center justify-between border-b border-slate-800 px-8 py-5">
                <h1 className="text-2xl font-bold">PackForge AI</h1>

                <button
                    onClick={handleLogout}
                    className="rounded-lg bg-red-600 px-4 py-2 hover:bg-red-700"
                >
                    Logout
                </button>
            </header>

            <section className="p-8">
                <h2 className="text-3xl font-bold">
                    Welcome 👋
                </h2>

                <p className="mt-2 text-slate-400">
                    Start creating AI-powered packaging designs.
                </p>

                <Link href="/design">
                    <button className="mt-8 rounded-lg bg-blue-600 px-6 py-3 font-semibold hover:bg-blue-700">
                        + New Packaging Design
                    </button>
                </Link>

                <div className="mt-10 rounded-xl border border-slate-800 bg-slate-900 p-6">
                    <h3 className="text-xl font-semibold">
                        My Projects
                    </h3>

                    {projects.length === 0 ? (
                        <p className="mt-3 text-slate-400">
                            No projects yet.
                        </p>
                    ) : (
                        <div className="mt-4 space-y-3">
                            {projects.map((project) => (
                                <div
                                    key={project.id}
                                    className="rounded-lg border border-slate-700 p-4"
                                >
                                    <h4 className="font-semibold">
                                        {project.project_name}
                                    </h4>

                                    <p className="text-sm text-slate-400">
                                        {project.brand_name}
                                    </p>
                                </div>
                            ))}
                        </div>
                    )}

                </div>
            </section>
        </main>
    );
}
