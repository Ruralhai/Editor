"use client";

import PackagingEditor from "@/components/editor/PackagingEditor";

export default function EditorPage() {
  return <PackagingEditor />;
}
