import { NextRequest, NextResponse } from "next/server";
import { ideogram } from "@/lib/ai/ideogram";
 
export async function POST(req: NextRequest) {
  try {
    const { prompt } = await req.json();
 
    const response = await ideogram.post(
      "/v1/ideogram-v4/generate",
      {
        text_prompt: prompt,
      }
    );
 
    return NextResponse.json({
      success: true,
      image: response.data.data[0].url,
    });
  } catch (error: any) {
    console.error(
      error.response?.data || error.message
    );
 
    return NextResponse.json(
      {
        success: false,
        error:
          error.response?.data || "Image generation failed",
      },
      { status: 500 }
    );
  }
}
 