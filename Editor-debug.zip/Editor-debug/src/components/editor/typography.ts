export const DEFAULT_TEXT_STYLE = {
    fontFamily: "Inter",
    fontSize: 16,
    fontStyle: "normal" as const,

    textAlign: "left" as const,

    lineHeight: 1.2,
    letterSpacing: 0,

    rotation: 0,
    opacity: 1,
};